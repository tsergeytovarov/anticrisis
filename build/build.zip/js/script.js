var href = document.querySelector(".crisis");

href.addEventListener("click", function(){
  var graf = document.querySelector(".grafik");
  graf.classList.add("active");
})
